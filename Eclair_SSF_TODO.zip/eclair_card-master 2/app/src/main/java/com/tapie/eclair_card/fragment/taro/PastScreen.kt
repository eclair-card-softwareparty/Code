//package com.tapie.eclair_card.fragment.taro
//
//import androidx.compose.foundation.Image
//import androidx.compose.foundation.background
//import androidx.compose.foundation.layout.Arrangement
//import androidx.compose.foundation.layout.Box
//import androidx.compose.foundation.layout.Column
//import androidx.compose.foundation.layout.Row
//import androidx.compose.foundation.layout.Spacer
//import androidx.compose.foundation.layout.fillMaxHeight
//import androidx.compose.foundation.layout.fillMaxSize
//import androidx.compose.foundation.layout.fillMaxWidth
//import androidx.compose.foundation.layout.height
//import androidx.compose.foundation.layout.padding
//import androidx.compose.foundation.layout.size
//import androidx.compose.foundation.layout.width
//import androidx.compose.material3.IconButton
//import androidx.compose.material3.Text
//import androidx.compose.runtime.Composable
//import androidx.compose.runtime.getValue
//import androidx.compose.runtime.livedata.observeAsState
//import androidx.compose.ui.Alignment
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.graphics.Color
//import androidx.compose.ui.res.painterResource
//import androidx.compose.ui.text.font.FontWeight
//import androidx.compose.ui.text.style.TextAlign
//import androidx.compose.ui.tooling.preview.Devices
//import androidx.compose.ui.tooling.preview.Preview
//import androidx.compose.ui.unit.dp
//import androidx.compose.ui.unit.sp
//import androidx.lifecycle.viewmodel.compose.viewModel
//import androidx.navigation.NavController
//import androidx.navigation.compose.rememberNavController
//import com.tapie.eclair_card.R
//import com.tapie.eclair_card.components.atomic.LogoIcon
//import com.tapie.eclair_card.components.atomic.typography.TaroTypography
//import com.tapie.eclair_card.components.nav.LengthNavigationBar
//import com.tapie.eclair_card.data.SharedViewModel
//import com.tapie.eclair_card.navigation.Screen
//
//@Composable
//fun PastScreen(navController: NavController, sharedViewModel: SharedViewModel = viewModel()) {
//    val pastCardNumber = sharedViewModel.selectedCards.value?.getOrNull(0)
//    // ViewModel에서 선택된 카드 목록에서 첫 번째 카드를 가져옴
//    Row(
//        modifier = Modifier
//            .fillMaxSize() // 화면 전체를 채움
//            ./*TODO 빈 칸 */ //배경색을 흰색으로 설정함
//    ) {
//        // 빈 공간을 위한 Box
//        Box(
//            modifier = Modifier
//                .width(50.dp) // 50dp의 너비를 가짐
//                .fillMaxHeight() // 세로로 화면 전체를 채움
//        )
//
//        Column(
//            modifier = Modifier
//                .weight(1f) // // 가능한 공간을 모두 차지함
//                ./*TODO 빈 칸 */, // 16dp의 안쪽 여백 설정
//            horizontalAlignment = Alignment.CenterHorizontally, // 가로 중앙 정렬
//            verticalArrangement = Arrangement.Center // 세로 중앙 정렬
//        ) {
//            Box(
//                modifier = Modifier
//                    .fillMaxWidth() // 가로로 화면 전체를 채움
//                    .padding(vertical = 4.dp) // 상단과 하단에 4dp의 여백을 줌
//            ) {
//                Row(
//                    verticalAlignment = Alignment.CenterVertically, // 세로 중앙 정렬
//                    horizontalArrangement = Arrangement.Start, // 가로 왼쪽 정렬
//                    modifier = Modifier.align(/*TODO 빈 칸 */)// 중앙 왼쪽 정렬
//                ) { // 뒤로 가기 버튼
//                    IconButton(onClick = {
//                        // Home 화면으로 이동함
//                        navController.navigate(Screen.Home.route) {
//                            // 이전 상태를 저장하고 복원함
//                            popUpTo(navController.graph.startDestinationId) {
//                                saveState = true
//                            }
//                            launchSingleTop = true // 같은 화면 반복 하지 않게 함
//                            restoreState = true // 이전에 있던 상태를 복원함
//                        }
//                    }) {
//                        Image(
//                            painter = painterResource(id = R.drawable.arrow_back_ios),
//                            contentDescription = "Back", // 이미지 설명 텍스트
//                            modifier = Modifier.size(24.dp) // 크기를 24dp로 설정함
//                        )
//                    }
//                }
//
//                Text(
//                    text = "타로",
//                    fontSize = 18.sp,
//                    modifier = Modifier.align(Alignment.Center)
//                )
//
//                Box(
//                    modifier = Modifier.align(Alignment.CenterEnd)
//                ) {
//                    LogoIcon(modifier = Modifier.size(24.dp))
//                }
//            }
//
//            Spacer(modifier = Modifier.height(16.dp)) // 상단 텍스트와 카드 사이의 간격
//
//            Column(
//                horizontalAlignment = Alignment.CenterHorizontally,
//                verticalArrangement = Arrangement.Center, // 세로 중앙 정렬
//                modifier = Modifier.fillMaxSize()
//            ) {
//                // 여기에 선택된 카드 번호에 따른 이미지를 표시
//                if (pastCardNumber != null) {
//                    val interpretation =
//                        DisplayPastCard(pastCardNumber, Modifier.size(230.dp, 380.dp))
//                    Spacer(modifier = Modifier.height(8.dp)) // 빈 공간 조정
//
//                    Text(
//                        text = "과거",
//                        style = TaroTypography.Time,
//                        textAlign = TextAlign.Center, // 텍스트를 가로로 중앙 정렬
//                        modifier = Modifier.fillMaxWidth()
//                    )
//
//                    Spacer(modifier = Modifier.height(4.dp))
//
//                    Text(
//                        text = interpretation,
//                        style = TaroTypography.Explain,
//                        modifier = Modifier.fillMaxWidth()
//                    )
//                }
//            }
//        }
//    }
//}