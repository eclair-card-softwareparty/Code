//package com.tapie.eclair_card.fragment.luck
//
//import LuckCardList
//import androidx.compose.foundation.Image
//import androidx.compose.foundation.background
//import androidx.compose.foundation.layout.*
//import androidx.compose.foundation.shape.CutCornerShape
//import androidx.compose.foundation.shape.RoundedCornerShape
//import androidx.compose.material3.IconButton
//import androidx.compose.material3.Text
//import androidx.compose.runtime.Composable
//import androidx.compose.runtime.getValue
//import androidx.compose.runtime.livedata.observeAsState
//import androidx.compose.ui.Alignment
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.graphics.Color
//import androidx.compose.ui.res.painterResource
//import androidx.compose.ui.unit.dp
//import androidx.compose.ui.unit.sp
//import androidx.lifecycle.viewmodel.compose.viewModel
//import androidx.navigation.NavController
//import com.tapie.eclair_card.R
//import com.tapie.eclair_card.components.atomic.LogoIcon
//import com.tapie.eclair_card.components.atomic.typography.LuckTypography
//import com.tapie.eclair_card.components.icon.GetIcon
//import com.tapie.eclair_card.data.SharedViewModel
//import com.tapie.eclair_card.navigation.Screen
//import com.tapie.eclair_card.ui.theme.GreenColor
//
//@Composable
//fun LuckScreen(navController: NavController, sharedViewModel: SharedViewModel = viewModel()) {
//    val num by sharedViewModel.num.observeAsState("")
//    // 숫자 데이터를 가져옴
//    val icon = GetIcon(num)
//    // 숫자에 따른 아이콘 가져오기
//    val fourIdioms by sharedViewModel.fourIdioms.observeAsState("")
//    // 사자성어 데이터를 가져옴
//
//    Column(
//        modifier = Modifier
//            ./*TODO 빈 칸 */ // 화면 전체를 채움
//            .padding(16.dp), // 전체 여백 설정
//        horizontalAlignment = Alignment.CenterHorizontally  // 모든 항목을 가로로 중앙 정렬
//    ) {
//        Box(
//            modifier = Modifier
//                .fillMaxWidth() // 가로 전체를 채움
//                ./*TODO 빈 칸 */ // 위아래 8.dp 여백 설정
//        ) {
//            Row(
//                verticalAlignment = Alignment./*TODO 빈 칸 */, // 항목을 세로로 중앙 정렬
//                horizontalArrangement = Arrangement.Start, // 항목을 가로로 시작 부분에 정렬
//                modifier = Modifier.align(Alignment.CenterStart) // 시작 부분에 위치시킴
//            ) {
//                IconButton(onClick = {
//                    // 뒤로 가기 버튼 클릭 시 홈 화면으로 이동
//                    navController.navigate(Screen.Home.route) {
//                        popUpTo(navController.graph.startDestinationId) {
//                            saveState = true // 이전 상태를 저장
//                        }
//                        launchSingleTop = true // 단일 인스턴스만 실행
//                        restoreState = true // 이전 상태를 복원
//                    }
//                }) { // 뒤로 가기 아이콘 이미지 설정
//                    Image(
//                        painter = painterResource(id = R.drawable.arrow_back_ios),
//                        contentDescription = "Back", // 이미지 설명
//                        modifier = Modifier./*TODO 빈 칸 */ // 이미지 크기 24.dp 설정
//                    )
//                }
//            }
//
//            // 운세 화면의 제목 텍스트
//            Text(
//                text = "운세",
//                fontSize = 18.sp, // 텍스트 크기 설정
//                modifier = Modifier.align(Alignment.Center) // 가로로 중앙에 위치시킴
//            )
//
//            Box(
//                modifier = Modifier.align(Alignment.CenterEnd) // 끝부분에 위치시킴
//            ) {
//                // 로고 아이콘 설정
//                LogoIcon(modifier = Modifier.size(24.dp))
//            }
//        }
//
//        Spacer(modifier = Modifier.height(16.dp)) // 제목과 이미지 사이에 공간 추가
//
//        // 운세 아이콘 이미지 설정
//        Image(
//            painter = painterResource(id = icon),
//            contentDescription = null,
//            modifier = Modifier.size(150.dp) // 이미지 크기 설정
//        )
//
//        /*TODO 빈 칸 */ // 이미지와 텍스트 사이에 8.dp만큼 공간 추가
//
//        Box(
//            contentAlignment = /*TODO 빈 칸 */, // 가운데 하단 정렬
//            modifier = Modifier.wrapContentSize() // 내용에 맞게 크기 조정
//        ) {
//            // 둥근 사각형 배경 박스
//            Box(
//                modifier = Modifier
//                    . /*TODO 빈 칸 */ // 높이 12.dp
//                    . /*TODO 빈 칸 */ // 너비 96.dp
//                    .background(color = GreenColor, shape = RoundedCornerShape(50)) // 배경색과 모양 설정
//                    .align(/*TODO 빈 칸 */) // 가운데 하단에 위치시킴
//            )
//
//            // 사자성어 텍스트
//            Text(
//                text = fourIdioms,
//                style = LuckTypography.Luck_four_idioms
//            )
//        }
//
//        /*TODO 빈 칸 */  // 추가 공간 30dp 설정
//
//        // 운세 카드를 나열하는 함수 호출
//        LuckCardList(
//            sharedViewModel = sharedViewModel,
//            cardWidth = 250,  // 카드의 너비 설정
//            cardHeight = 320  // 카드의 높이 설정
//        )
//    }
//}