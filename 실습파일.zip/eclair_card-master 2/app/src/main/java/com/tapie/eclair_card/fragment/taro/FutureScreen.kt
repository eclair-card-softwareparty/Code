//package com.tapie.eclair_card.fragment.taro
//
//import androidx.compose.foundation.Image
//import androidx.compose.foundation.background
//import androidx.compose.foundation.layout.Arrangement
//import androidx.compose.foundation.layout.Box
//import androidx.compose.foundation.layout.Column
//import androidx.compose.foundation.layout.Row
//import androidx.compose.foundation.layout.Spacer
//import androidx.compose.foundation.layout.fillMaxHeight
//import androidx.compose.foundation.layout.fillMaxSize
//import androidx.compose.foundation.layout.fillMaxWidth
//import androidx.compose.foundation.layout.height
//import androidx.compose.foundation.layout.padding
//import androidx.compose.foundation.layout.size
//import androidx.compose.foundation.layout.width
//import androidx.compose.material3.IconButton
//import androidx.compose.material3.Text
//import androidx.compose.runtime.Composable
//import androidx.compose.ui.Alignment
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.graphics.Color
//import androidx.compose.ui.res.painterResource
//import androidx.compose.ui.text.style.TextAlign
//import androidx.compose.ui.unit.dp
//import androidx.compose.ui.unit.sp
//import androidx.lifecycle.viewmodel.compose.viewModel
//import androidx.navigation.NavController
//import com.tapie.eclair_card.R
//import com.tapie.eclair_card.components.atomic.LogoIcon
//import com.tapie.eclair_card.components.atomic.typography.TaroTypography
//import com.tapie.eclair_card.data.SharedViewModel
//import com.tapie.eclair_card.navigation.Screen
//
//@Composable
//fun FutureScreen(navController: NavController, sharedViewModel: SharedViewModel = viewModel()) {
//    val futureCardNumber = sharedViewModel.selectedCards.value?.getOrNull(2)
//
//    Row(
//        modifier = Modifier
//            ./* TODO 빈 칸 */ // 전체 화면을 채움
//            ./* TODO 빈 칸 */ // 배경색을 흰색으로 설정
//    ) {
//        // 빈 공간을 위한 Box
//        Box(
//            modifier = Modifier
//                .width(50.dp) // 50.dp의 넓이로 설정
//                .fillMaxHeight() // 세로로 화면 전체를 채움
//        )
//
//        /* TODO 빈 칸 */ ( // 세로 방향 요소 배치
//            modifier = Modifier
//                ./* TODO 빈 칸 */ // 남은 공간을 모두 차지하게 함
//                ./* TODO 빈 칸 */ // 16.dp의 여백을 줌,
//            horizontalAlignment = /* TODO 빈 칸 */ // 가로 중앙 정렬
//            verticalArrangement = /* TODO 빈 칸 */ // 세로 중앙 정렬
//        ) {
//            Box(
//                modifier = Modifier
//                    ./* TODO 빈 칸 */ // 가로로 화면 전체를 채움
//                    .padding(vertical = 4.dp) // 상단의 여백을 최소화
//            ) {
//                Row(
//                    verticalAlignment = Alignment.CenterVertically,
//                    horizontalArrangement = Arrangement.Start,
//                    modifier = Modifier.align(Alignment.CenterStart)
//                ) {
//                    IconButton(onClick = {
//                        navController.navigate(Screen.Home.route) {
//                            popUpTo(navController.graph.startDestinationId) {
//                                saveState = true
//                            }
//                            launchSingleTop = true
//                            restoreState = true
//                        }
//                    }) {
//                        Image(
//                            painter = painterResource(id = R.drawable.arrow_back_ios),
//                            contentDescription = "Back",
//                            modifier = Modifier./* TODO 빈 칸 */ // 크기를 24.dp 로 설정
//                        )
//                    }
//                }
//
//                Text(
//                    text = "타로",
//                    fontSize = 18.sp,
//                    modifier = Modifier.align(Alignment.Center)
//                )
//
//                Box(
//                    modifier = Modifier.align(Alignment.CenterEnd)
//                ) {
//                    LogoIcon(modifier = Modifier.size(24.dp))
//                }
//            }
//
//            // 상단 텍스트와 카드 사이의 간격
//            /* TODO 빈 칸 */ // 16.dp 높이 여백 추가
//
//            Column(
//                horizontalAlignment = Alignment.CenterHorizontally,
//                verticalArrangement = Arrangement.Center, // 세로 중앙 정렬
//                modifier = Modifier.fillMaxSize()
//            ) {
//                // 여기에 선택된 카드 번호에 따른 이미지를 표시
//                if (futureCardNumber != null) {
//                    val interpretation = DisplayFutureCard(futureCardNumber,
//                        Modifier./* TODO 빈 칸 */  // 카드 크기를 가로 230.dp 세로 380.dp로 설정 )
//
//                    /* TODO 빈 칸 */ // 8.dp 높이 여백 추가
//
//                    Text(
//                        /* TODO 빈 칸 */ // text 를 '미래' 로 설정 ,
//                        /* TODO 빈 칸 */ // 텍스트 스타일을 TaroTypography.Time으로 설정 ,
//                        textAlign = TextAlign.Center, // 텍스트를 가로로 중앙 정렬
//                        modifier = Modifier.fillMaxWidth()
//                    )
//
//                    /* TODO 빈 칸 */ // 4.dp 높이 여백 추가
//
//                    Text(
//                        text = interpretation,
//                        style = TaroTypography.Explain,
//                        modifier = Modifier.fillMaxWidth()
//                    )
//                }
//            }
//        }
//    }
//}